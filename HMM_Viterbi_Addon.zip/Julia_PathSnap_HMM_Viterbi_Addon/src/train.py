"""Train registered PathSnap models.

The MLP path is implemented here end-to-end because it must record train and
validation log loss after every epoch. Other model owners can add their model
names to src.model_zoo.MODEL_ZOO and extend the dispatcher without changing
Julia's MLP training path.

Run after `python -m src.build_dataset`:
    python -m src.train --model mlp
    python -m src.train --model mlp --quick
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.metrics import log_loss
from sklearn.model_selection import GroupKFold
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler

from . import evaluate
from .config import ARTIFACTS_DIR, N_FOLDS, PROCESSED_DIR, RESULTS_DIR, SEED
from .features import FEATURE_COLUMNS, load_or_build, save_feature_list
from .model_zoo import MLP_CONFIG, MODEL_ZOO, make_mlp

MAX_TRAIN_ROWS = 500_000


def _sample_training_rows(frame: pd.DataFrame, max_rows: int, seed: int) -> pd.DataFrame:
    rows = frame[frame.fix_valid.astype(bool)]
    if len(rows) <= max_rows:
        return rows
    frac = max_rows / len(rows)
    sampled = rows.groupby("label", group_keys=False).sample(frac=frac, random_state=seed)
    return sampled.sample(frac=1.0, random_state=seed).reset_index(drop=True)


def _prepare(train_rows: pd.DataFrame, other: pd.DataFrame):
    imputer = SimpleImputer(strategy="median")
    x_train = imputer.fit_transform(train_rows[FEATURE_COLUMNS].to_numpy(dtype="float64"))
    x_other = imputer.transform(other[FEATURE_COLUMNS].to_numpy(dtype="float64"))
    scaler = StandardScaler()
    x_train = scaler.fit_transform(x_train)
    x_other = scaler.transform(x_other)
    return x_train, x_other, imputer, scaler


def _fit_epochwise(x_train, y_train, x_val, y_val, epochs: int, seed: int):
    if len(np.unique(y_train)) < 2:
        raise ValueError("MLP training rows must contain both candidate classes")
    model = MLPClassifier(
        hidden_layer_sizes=tuple(MLP_CONFIG["hidden_layer_sizes"]),
        activation=MLP_CONFIG["activation"], solver=MLP_CONFIG["solver"],
        learning_rate_init=MLP_CONFIG["learning_rate_init"], alpha=MLP_CONFIG["alpha"],
        batch_size=MLP_CONFIG["batch_size"], max_iter=1, random_state=seed,
        shuffle=True, tol=0.0, n_iter_no_change=epochs + 1,
    )
    history = []
    for epoch in range(1, epochs + 1):
        if epoch == 1:
            model.partial_fit(x_train, y_train, classes=np.array([0, 1]))
        else:
            model.partial_fit(x_train, y_train)
        p_train = np.clip(model.predict_proba(x_train)[:, 1], 1e-6, 1 - 1e-6)
        train_loss = float(log_loss(y_train, p_train, labels=[0, 1]))
        if x_val is not None and len(y_val):
            p_val = np.clip(model.predict_proba(x_val)[:, 1], 1e-6, 1 - 1e-6)
            val_loss = float(log_loss(y_val, p_val, labels=[0, 1]))
        else:
            val_loss = float("nan")
        history.append({"epoch": epoch, "train_log_loss": train_loss,
                        "validation_log_loss": val_loss})
    return model, pd.DataFrame(history)


def _metrics_with_probability(cand, prob, fixes):
    out = evaluate.evaluate_predictions(cand, prob, fixes)
    return out


def run_mlp(quick: bool = False):
    started = time.perf_counter()
    train_cand = load_or_build("train")
    train_fixes = pd.read_parquet(RESULTS_DIR.parent / "data" / "processed" / "fixes_train.parquet")
    test_cand = load_or_build("student_test")
    test_fixes = pd.read_parquet(RESULTS_DIR.parent / "data" / "processed" / "fixes_student_test.parquet")

    if quick:
        # Smoke-test mode is deliberately small and is not a reportable result.
        keep_trips = sorted(train_cand.trip_id.astype(str).unique())[:10]
        train_cand = train_cand[train_cand.trip_id.astype(str).isin(keep_trips)].reset_index(drop=True)
        train_fixes = train_fixes[train_fixes.trip_id.astype(str).isin(keep_trips)].reset_index(drop=True)
        test_trips = sorted(test_cand.trip_id.astype(str).unique())[:2]
        test_cand = test_cand[test_cand.trip_id.astype(str).isin(test_trips)].reset_index(drop=True)
        test_fixes = test_fixes[test_fixes.trip_id.astype(str).isin(test_trips)].reset_index(drop=True)

    n_folds = min(N_FOLDS, train_cand.trip_id.nunique())
    if n_folds < 2:
        raise ValueError("Need at least two training trips for GroupKFold")
    folds = GroupKFold(n_splits=n_folds)
    trip_ids = train_cand.trip_id.to_numpy()
    cv_rows, curve_rows = [], []
    for fold, (tr_idx, va_idx) in enumerate(folds.split(train_cand, groups=trip_ids)):
        tr = train_cand.iloc[tr_idx].reset_index(drop=True)
        va = train_cand.iloc[va_idx].reset_index(drop=True)
        va_trip_ids = set(va.trip_id.astype(str).unique())
        va_fix = train_fixes[train_fixes.trip_id.astype(str).isin(va_trip_ids)].reset_index(drop=True)
        tr_rows = _sample_training_rows(tr, MAX_TRAIN_ROWS, SEED + fold)
        x_tr, x_va, imputer, scaler = _prepare(tr_rows, va)
        y_tr = tr_rows.label.to_numpy(dtype="int64")
        y_va = va.label.to_numpy(dtype="int64")
        t0 = time.perf_counter()
        model, history = _fit_epochwise(x_tr, y_tr, x_va, y_va, MLP_CONFIG["epochs"], SEED + fold)
        fit_s = time.perf_counter() - t0
        t0 = time.perf_counter()
        p_va = model.predict_proba(x_va)[:, 1]
        pred_s = time.perf_counter() - t0
        rec = _metrics_with_probability(va, p_va, va_fix)
        rec.update({"fold": fold, "n_train_trips": tr.trip_id.nunique(),
                    "n_val_trips": va.trip_id.nunique(), "train_time_s": fit_s,
                    "infer_ms_per_1k_fixes": evaluate.per_1k_fixes_ms(pred_s, va)})
        cv_rows.append(rec)
        history["fold"] = fold
        curve_rows.extend(history.to_dict("records"))
        print(f"fold {fold}: Top-1={rec['top1']:.4f}, macro-F1={rec['macro_f1']:.4f}, "
              f"log-loss={rec['log_loss']:.4f}", flush=True)

    # Refit on all training trips, then evaluate once on student_test.
    final_rows = _sample_training_rows(train_cand, MAX_TRAIN_ROWS, SEED)
    x_train, x_test, imputer, scaler = _prepare(final_rows, test_cand)
    y_train = final_rows.label.to_numpy(dtype="int64")
    y_test = test_cand.label.to_numpy(dtype="int64")
    t0 = time.perf_counter()
    model, final_history = _fit_epochwise(x_train, y_train, None, np.array([]),
                                          MLP_CONFIG["epochs"], SEED)
    fit_s = time.perf_counter() - t0
    t0 = time.perf_counter()
    p_test = model.predict_proba(x_test)[:, 1]
    infer_s = time.perf_counter() - t0
    test_metrics = _metrics_with_probability(test_cand, p_test, test_fixes)
    n_test_fixes = test_fixes[["trip_id", "fix_idx"]].drop_duplicates().shape[0]
    test_metrics.update({"training_time_s": fit_s, "inference_time_s": infer_s,
                         "inference_ms_per_1k_fixes": infer_s * 1e6 / max(n_test_fixes, 1),
                         "n_training_rows": int(len(final_rows)), "n_training_trips": int(train_cand.trip_id.nunique())})

    out_dir = RESULTS_DIR / "models" / "mlp"
    out_dir.mkdir(parents=True, exist_ok=True)
    cv_df = pd.DataFrame(cv_rows)
    curve_df = pd.DataFrame(curve_rows)
    cv_df.to_csv(out_dir / "cv_folds.csv", index=False)
    curve_df.to_csv(out_dir / "loss_history_cv.csv", index=False)
    final_history.to_csv(out_dir / "final_loss_history.csv", index=False)
    (out_dir / "student_test_metrics.json").write_text(json.dumps(test_metrics, indent=2), encoding="utf-8")
    config = {**MLP_CONFIG, "model_id": "mlp", "family": "neural_network", "owner": "Julia",
              "seed": SEED, "n_folds": n_folds, "group_column": "trip_id",
              "max_train_rows_per_fold": MAX_TRAIN_ROWS, "max_final_train_rows": MAX_TRAIN_ROWS,
              "feature_columns": FEATURE_COLUMNS, "student_test_metrics": test_metrics,
              "preprocessing": "Median imputation and StandardScaler fitted on training data only."}
    (out_dir / "config.json").write_text(json.dumps(config, indent=2), encoding="utf-8")

    # Save model, preprocessing and exact ordered features under a non-conflicting name.
    ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)
    bundle = {"model": model, "scaler": scaler,
              "medians": dict(zip(FEATURE_COLUMNS, imputer.statistics_.tolist())),
              "feature_columns": list(FEATURE_COLUMNS), "config": config}
    joblib.dump(bundle, ARTIFACTS_DIR / "mlp_model.joblib")
    save_feature_list(ARTIFACTS_DIR / "features.json")

    # Plots are regenerated from the saved per-epoch CSVs.
    fig, ax = plt.subplots(figsize=(8, 4.5))
    for fold, grp in curve_df.groupby("fold"):
        ax.plot(grp.epoch, grp.train_log_loss, alpha=0.55, label=f"Fold {fold} train")
        ax.plot(grp.epoch, grp.validation_log_loss, alpha=0.75, linestyle="--", label=f"Fold {fold} validation")
    ax.set(xlabel="Epoch", ylabel="Log loss", title="MLP cross-validation loss by epoch")
    ax.grid(True, alpha=0.25)
    ax.legend(ncol=2, fontsize=7)
    fig.tight_layout()
    fig.savefig(out_dir / "cv_loss_curves.png", dpi=160, bbox_inches="tight")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot(final_history.epoch, final_history.train_log_loss, marker="o", label="Training")
    ax.set(xlabel="Epoch", ylabel="Log loss", title="Final MLP training loss")
    ax.grid(True, alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_dir / "final_training_loss.png", dpi=160, bbox_inches="tight")
    plt.close(fig)

    comparison_path = RESULTS_DIR / "models" / "model_comparison.csv"
    comparison_path.parent.mkdir(parents=True, exist_ok=True)
    row = {"model": "mlp", "family": "neural_network",
           "cv_macro_f1": float(cv_df.macro_f1.mean()), "cv_macro_f1_std": float(cv_df.macro_f1.std(ddof=1)),
           "student_test_top1": test_metrics["top1"], "student_test_macro_f1": test_metrics["macro_f1"],
           "student_test_log_loss": test_metrics["log_loss"],
           "inference_ms_per_1k_fixes": test_metrics["inference_ms_per_1k_fixes"],
           "training_time_s": fit_s}
    existing = pd.read_csv(comparison_path) if comparison_path.exists() else pd.DataFrame()
    existing = existing[existing.get("model", pd.Series(dtype=str)).astype(str) != "mlp"] if len(existing) else existing
    pd.concat([existing, pd.DataFrame([row])], ignore_index=True).to_csv(comparison_path, index=False)

    print(f"MLP student-test Top-1={test_metrics['top1']:.4f}, macro-F1={test_metrics['macro_f1']:.4f}, "
          f"log-loss={test_metrics['log_loss']:.4f}")
    print(f"Completed in {time.perf_counter() - started:.1f}s; results: {out_dir}")
    return cv_df, test_metrics


def run_generic(model_name: str, quick: bool = False):
    """Shared non-MLP training path for teammate estimators in MODEL_ZOO."""
    family, factory, params = MODEL_ZOO[model_name]
    train_cand = load_or_build("train")
    train_fixes = pd.read_parquet(PROCESSED_DIR / "fixes_train.parquet")
    test_cand = load_or_build("student_test")
    test_fixes = pd.read_parquet(PROCESSED_DIR / "fixes_student_test.parquet")
    if quick:
        keep = sorted(train_cand.trip_id.astype(str).unique())[:10]
        train_cand = train_cand[train_cand.trip_id.astype(str).isin(keep)].reset_index(drop=True)
        train_fixes = train_fixes[train_fixes.trip_id.astype(str).isin(keep)].reset_index(drop=True)
    cv = evaluate.group_cv(factory, params, train_cand, train_fixes, FEATURE_COLUMNS,
                           n_folds=min(N_FOLDS, train_cand.trip_id.nunique()), verbose=True)
    rows = evaluate.training_rows(train_cand, MAX_TRAIN_ROWS, SEED)
    model = factory(**params)
    t0 = time.perf_counter()
    model.fit(rows[FEATURE_COLUMNS].to_numpy(dtype="float64"), rows.label.to_numpy(dtype="int64"))
    fit_s = time.perf_counter() - t0
    t0 = time.perf_counter()
    p_test = model.predict_proba(test_cand[FEATURE_COLUMNS].to_numpy(dtype="float64"))[:, 1]
    infer_s = time.perf_counter() - t0
    metrics = evaluate.evaluate_predictions(test_cand, p_test, test_fixes)
    nfix = test_fixes[["trip_id", "fix_idx"]].drop_duplicates().shape[0]
    metrics.update({"training_time_s": fit_s, "inference_time_s": infer_s,
                    "inference_ms_per_1k_fixes": infer_s * 1e6 / max(nfix, 1)})
    out_dir = RESULTS_DIR / "models" / model_name
    out_dir.mkdir(parents=True, exist_ok=True)
    cv.to_csv(out_dir / "cv_folds.csv", index=False)
    (out_dir / "student_test_metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    config = {"model_id": model_name, "family": family, "seed": SEED,
              "n_folds": int(min(N_FOLDS, train_cand.trip_id.nunique())),
              "feature_columns": FEATURE_COLUMNS, "parameters": params,
              "student_test_metrics": metrics}
    (out_dir / "config.json").write_text(json.dumps(config, indent=2, default=str), encoding="utf-8")
    ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, ARTIFACTS_DIR / f"{model_name}_model.joblib")
    row = {"model": model_name, "family": family,
           "cv_macro_f1": float(cv.macro_f1.mean()), "cv_macro_f1_std": float(cv.macro_f1.std(ddof=1)),
           "student_test_top1": metrics["top1"], "student_test_macro_f1": metrics["macro_f1"],
           "student_test_log_loss": metrics["log_loss"],
           "inference_ms_per_1k_fixes": metrics["inference_ms_per_1k_fixes"],
           "training_time_s": fit_s}
    comparison_path = RESULTS_DIR / "models" / "model_comparison.csv"
    existing = pd.read_csv(comparison_path) if comparison_path.exists() else pd.DataFrame()
    if "model" in existing:
        existing = existing[existing.model.astype(str) != model_name]
    pd.concat([existing, pd.DataFrame([row])], ignore_index=True).to_csv(comparison_path, index=False)
    return cv, metrics


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", required=True, choices=sorted(MODEL_ZOO))
    parser.add_argument("--quick", action="store_true")
    args = parser.parse_args(argv)
    if args.model == "mlp":
        run_mlp(quick=args.quick)
    else:
        run_generic(args.model, quick=args.quick)


if __name__ == "__main__":
    main()
