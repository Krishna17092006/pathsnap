"""Model registry for PathSnap.

The shared registry is intentionally extensible: each model owner should add
one entry here rather than creating a separate registry. Julia's MLP is the
first entry in this repository snapshot.
"""
from __future__ import annotations

from sklearn.neural_network import MLPClassifier


MLP_CONFIG = {
    "hidden_layer_sizes": (128, 64),
    "activation": "relu",
    "solver": "adam",
    "learning_rate_init": 1e-3,
    "alpha": 1e-4,
    "batch_size": 8192,
    "epochs": 20,
    "random_state": 42,
}


def make_mlp(**overrides) -> MLPClassifier:
    """Create the MLP estimator used by the PathSnap candidate classifier."""
    config = {**MLP_CONFIG, **overrides}
    epochs = int(config.pop("epochs", 20))
    return MLPClassifier(max_iter=epochs, **config)


# Contract from TEAM.md: name -> (family, factory_function, config_dict).
MODEL_ZOO = {
    "mlp": ("neural_network", make_mlp, dict(MLP_CONFIG)),
}


def register_model(name: str, family: str, factory, config: dict) -> None:
    """Register a teammate's estimator without replacing an existing model."""
    if name in MODEL_ZOO:
        raise KeyError(f"Model {name!r} is already registered")
    MODEL_ZOO[name] = (family, factory, dict(config))


def get_model(name: str):
    try:
        return MODEL_ZOO[name]
    except KeyError as exc:
        raise KeyError(f"Unknown model {name!r}. Available models: {sorted(MODEL_ZOO)}") from exc
